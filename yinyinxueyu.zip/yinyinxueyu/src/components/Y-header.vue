<template>
  <header>
    <div class="bg"></div>
    <nav>
      <ul>
        <li><span>111</span></li>
        <li><span>111</span></li>
        <li style=""><img src="{{headerurl}}"/></li>
      </ul>
    </nav>
  </header>
</template>
<script>
export default{
    data(){
      return {
        headerurl:'./assets/img/timg.jpg'
      }
    }
}
</script>
<style scoped>
  header{
    height: 30rem;
    display: flex;
    flex-direction: column;
  }
  .bg{
    z-index: -1;
    position: absolute;
    height:30rem;
    width: 100%;
    left:0;
    top:0;
    background-color: #fff;
    /*background-size: cover; 必须放在background-position后面用 "/" 分割*/
    /*background:  url('./assets/img/timg.jpg') no-repeat center /cover;*/
    /* brightness()给图片应用一种线性乘法，使其看起来更亮或更暗。如果值是0%，图像会全黑。值是100%，
    则图像无变化。其他的值对应线性乘数效果。值超过100%也是可以的，图像会比原来更亮。如果没有设定值，默认是1。*/
    filter: brightness(0.7);
  }
  nav ul{
    display: flex;
    display: -webkit-flex;
    -webkit-justify-content:flex-end;
    justify-content: flex-end;
    margin:0;
    list-style: none;
  }
</style>
